python3 f256-sprite-cutter.py ../assets/ImpasseSprites.png ../assets/ImpassSprites.txt ../src/sprites_dat.s
