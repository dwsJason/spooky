# impass-f256

Done for F256 April Game jam.

I only got about 14 hours of work in so this is not a full game but a tech demo.  
I'd like to finish it but we'll see. 


## Includes
This repo includes:
- An image conversion script to cut sprites
- Demo pgz file to run on your system
- Source code and assets to build it

